## Shadowsocks Manyuser
This is a based python multi-user derivative version of shadowsocks.

Fork in https://github.com/mengskysama/shadowsocks/tree/manyuser
