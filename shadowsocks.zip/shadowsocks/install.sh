#!/bin/bash
yum install m2crypto -y

python get-pip.py
pip install cymysql
