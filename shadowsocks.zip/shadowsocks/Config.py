#Config
MYSQL_HOST = 'www.68zz.gq'
MYSQL_PORT = 3306
MYSQL_USER = 'zzgq_ss'
MYSQL_PASS = '130130'
MYSQL_DB = 'zzgq_ss'

MANAGE_PASS = '123456'
#if you want manage in other server you should set this value to global ip
MANAGE_BIND_IP = '127.0.0.1'
#make sure this port is idle
MANAGE_PORT = 8888
